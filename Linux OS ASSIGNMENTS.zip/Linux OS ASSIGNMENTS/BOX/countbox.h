#ifndef __COUNTBOX_H
#define __COUNTBOX_H

#include"box.h"


int count_box(int *bptr,int GivUniq_Id);


#endif