#include "box.h"
#include "countbox.h"

int main()
{  //.... other chunk code

     int number_of_boxes;
   
    int Blackcount,Bluecount,Redcount;
    count_box(int *bptr,int GivUniq_Id);

      printf("\nEno. of Black Blue and Red Colors Are %d %d %d",Blackcount,Bluecount,Redcount);
    
  //.... other chunk code


      return 0; 
}