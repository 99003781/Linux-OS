#include <stdio.h> 
#include"bitmask.h"

// Function to set the kth bit of n 
int set(int a, int b) 
{  a=a | (1<<b);
    return a; 
} 
// Function to clear the kth bit of n 
int reset(int a, int b) 

{ a=a & (~0);
    return a;
} 
// Function to toggle the kth bit of n 
int flip(int a, int b) 
{ a=a^(1<<b);
    return a; 
} 