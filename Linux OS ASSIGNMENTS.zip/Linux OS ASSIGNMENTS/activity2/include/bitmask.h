/**
 * @file bitmask.h
 * @author Aman Shivachh (aman.shivachh@ltts.com)
 * @brief This file stores header for bitmask
 * @version 0.1
 * @date 2021-02-23
 * 
 * @copyright Copyright (c) 2021
 * 
 */

# ifndef __BITMASK_H__
# define __BITMASK_H__

int set(int a, int b);
int reset(int a, int b);
int flip(int a, int b);

# endif 